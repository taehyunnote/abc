package idusw.soccerworld.service;

import org.springframework.stereotype.Service;

@Service
public class MemberService {

}
