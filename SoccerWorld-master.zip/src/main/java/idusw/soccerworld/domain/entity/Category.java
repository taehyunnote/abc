package idusw.soccerworld.domain.entity;

import lombok.Data;

@Data
public class Category {
    private Long category_id;
    private String name;
}
