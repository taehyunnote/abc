package idusw.soccerworld.domain.entity;

import lombok.Data;

@Data
public class Member {
    private Long memberId;
}
