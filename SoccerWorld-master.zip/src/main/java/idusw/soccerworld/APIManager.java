package idusw.soccerworld;

import org.springframework.http.RequestEntity;
import org.springframework.web.client.RestTemplate;

public class APIManager {
//    String key = "f843e212b2msh30b828b108fb8d4p1b54b4jsn959c140e5e1d";
//    RestTemplate restTemplate = new RestTemplate();
//    RequestEntity<Void> req = RequestEntity
//            .get("https://v3.football.api-sports.io/fixtures?date=" + stringToday + "&league=39&season=2024").header("x-rapidapi-key", "73b2b917e94580c8bd9bb06ab1b77f14").build();
//
//    String result = restTemplate.exchange(req, String.class).getBody(); //결과를 String을 받음 .getBody로 Body부분 얻음
}
